// A JavaScript copy of the spelling rules (SpellingModule.cs), used to test the rules and to drive the test page.
export const WORDS = [
  ["imagine", "picture something in your mind", "Close your eyes and ____ a big pink castle."],
  ["bounce", "spring back after hitting something", "The ball will ____ on the floor."],
  ["inventor", "a person who creates something for the first time", "The ____ made a new toy."],
  ["observer", "someone who watches something", "The ____ watched the birds from the window."],
  ["alliteration", "several words or syllables in a row start with the same sound", "\"Silly snakes slide slowly\" is an example of ____."],
  ["free verse", "poem in which some verses rhyme and some do not", "My poem is ____, so not all the lines rhyme."],
  ["limerick", "a funny poem of five lines with a specific rhyme pattern", "I read a funny ____ to my class."],
  ["rhyme", "when words end with the same sound", "\"Cat\" and \"hat\" make a ____."]
];
export const MAX_TRIES = 6;
const letters = (w) => w.replace(/ /g, "").toLowerCase();

export function newGame(order = WORDS.map((_, i) => i)) {
  return { order, index: 0, phase: "define", showDef: true, showSentence: false, rows: [], current: "", outcome: 0, results: WORDS.map(() => 0), events: 0 };
}
export const wordOf = (s) => WORDS[s.order[s.index]][0];

export function validate(s, seat, a) {
  if (s.phase === "done") return "This game is already over.";
  if (seat !== 0) return "You are watching. Only the speller can play.";
  const len = s.phase === "done" ? 0 : letters(wordOf(s)).length;
  switch (a.kind) {
    case "ready": return s.phase === "define" || (s.phase === "spell" && s.showDef) ? null : "There is no definition to close.";
    case "define": case "sentence": return s.phase === "spell" && !s.showDef ? null : "The definition and the sentence can be shown while you spell.";
    case "letter":
      if (s.phase !== "spell" || s.showDef) return "Not spelling right now.";
      if (!/^[a-z]$/.test(a.ch || "")) return "Letters a to z only.";
      return s.current.length >= len ? "That row is full." : null;
    case "back": return s.phase === "spell" && !s.showDef && s.current.length > 0 ? null : "Nothing to erase.";
    case "enter":
      if (s.phase !== "spell" || s.showDef) return "Not spelling right now.";
      return s.current.length === len ? null : "Fill in every box first.";
    case "next": return s.phase === "result" ? null : "Finish this word first.";
    default: return "Unknown move.";
  }
}

export function apply(s, seat, a) {
  const err = validate(s, seat, a);
  if (err) throw new Error(err);
  const n = { ...s, events: s.events + 1 };
  switch (a.kind) {
    case "ready": n.phase = "spell"; n.showDef = false; n.showSentence = false; break;
    case "define": n.showDef = true; n.showSentence = false; break;
    case "sentence": n.showDef = true; n.showSentence = true; break;
    case "letter": n.current = s.current + a.ch; break;
    case "back": n.current = s.current.slice(0, -1); break;
    case "enter": {
      const right = s.current === letters(wordOf(s));
      n.rows = [...s.rows, s.current]; n.current = "";
      if (right || n.rows.length >= MAX_TRIES) { n.phase = "result"; n.outcome = right ? 1 : 2; n.results = [...s.results]; n.results[s.index] = n.outcome; }
      break;
    }
    case "next":
      n.index = s.index + 1; n.rows = []; n.current = ""; n.outcome = 0;
      if (n.index >= WORDS.length) n.phase = "done"; else { n.phase = "define"; n.showDef = true; }
      break;
  }
  return n;
}

// What the screens are sent (the word itself only once the word is finished).
export function viewOf(s) {
  const done = s.phase === "done", w = done ? null : WORDS[s.order[s.index]][0];
  return {
    phase: s.phase, showDef: s.showDef, panel: s.showSentence ? "sentence" : "definition", sentence: done ? null : WORDS[s.order[s.index]][2],
    marks: done ? [] : s.rows.map(r => mark(letters(w), r)), index: s.index, total: WORDS.length,
    length: done ? 0 : letters(w).length, gap: done ? -1 : w.indexOf(" "),
    definition: done ? null : WORDS[s.order[s.index]][1], rows: s.rows, current: s.current, maxTries: MAX_TRIES,
    outcome: s.outcome === 1 ? "correct" : s.outcome === 2 ? "missed" : "none", word: s.phase === "result" ? w : null,
    list: WORDS.map((w, o) => ({ word: w[0], result: s.results[s.order.indexOf(o)] })),
    correct: s.results.filter(r => r === 1).length, events: s.events,
    summary: done ? s.order.map((o, i) => ({ word: WORDS[o][0], ok: s.results[i] === 1 })) : null
  };
}
export function mark(target, guess) {
  const left = {}; for (let i = 0; i < target.length; i++) if (guess[i] !== target[i]) left[target[i]] = (left[target[i]] || 0) + 1;
  return [...guess].map((c, i) => c === target[i] ? "2" : left[c] > 0 ? (left[c]--, "1") : "0").join("");
}
export const lettersOf = letters;
