// "Listen and spell": the word is read out loud, and you type it. Same Wordle-style grid as the other spelling game
// (pink = right spot, purple = right letter in another spot, black = not in the word), but no definition and no word list.
import { h } from "./ui.js";
import { mark } from "./rules.js";

export const LISTEN_WORDS = ["trumpet", "helmets", "magnet", "rocket", "jackets", "cricket", "ticket", "basket", "planet", "bucket", "packet", "velvet", "habit", "limit"];
const MAX_TRIES = 6;
const KEY_ROWS = ["QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM"];

export const CONTRACTION_WORDS = ["you've", "what's", "doesn't", "there's", "you're", "we're", "they're", "shouldn't", "wouldn't", "he'd", "couldn't", "don't", "isn't", "she'd", "that's", "wasn't", "we'll", "we've", "I've", "didn't"];

const shuffled = (n) => {
  const o = Array.from({ length: n }, (_, i) => i);
  for (let i = o.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [o[i], o[j]] = [o[j], o[i]]; }
  return o;
};

// Picks the clearest English voice this device has: the "natural" / "online" voices first, then well-known good ones.
function bestVoice() {
  const voices = (window.speechSynthesis.getVoices() || []).filter(v => /^en/i.test(v.lang));
  const score = (v) => {
    let n = 0;
    if (/^en[-_]US/i.test(v.lang)) n += 20;
    if (/natural|neural|online/i.test(v.name)) n += 50;
    if (/aria|jenny|ava|andrew|emma|guy/i.test(v.name)) n += 15;
    if (/google us english/i.test(v.name)) n += 40;
    if (/samantha|allison|ava|nicky|evan/i.test(v.name)) n += 30;
    if (/enhanced|premium/i.test(v.name)) n += 30;
    if (/espeak|compact/i.test(v.name)) n -= 40;
    return n;
  };
  return voices.sort((a, b) => score(b) - score(a))[0] || null;
}

export function getVolume() {
  try { const v = parseFloat(localStorage.getItem("bmee.vol")); if (v >= 0 && v <= 1) return v; } catch (e) { /* ignore */ }
  return 1;
}
function setVolume(v) { try { localStorage.setItem("bmee.vol", String(v)); } catch (e) { /* ignore */ } }

/** Reads a word out loud, slowly and clearly, with the browser's own voice. Returns false if this browser can't talk. */
export function say(word) {
  const synth = window.speechSynthesis;
  if (!synth || typeof SpeechSynthesisUtterance === "undefined") return false;
  try {
    synth.cancel();
    const u = new SpeechSynthesisUtterance(word);
    u.lang = "en-US";
    u.rate = 0.7;      // a little slower than normal so every sound can be heard
    u.pitch = 0.75;
    u.volume = getVolume();
    const voice = bestVoice();
    if (voice) u.voice = voice;
    synth.speak(u);
    return true;
  } catch (e) { return false; }
}

// Some browsers only finish loading their voices a moment after the page opens.
try { if (window.speechSynthesis) window.speechSynthesis.onvoiceschanged = () => window.speechSynthesis.getVoices(); } catch (e) { /* ignore */ }

export function createListen(area, speak = say, opts = {}) {
  const words = opts.words || LISTEN_WORDS, title = opts.title || "Listen and spell", apos = !!opts.apostrophe;
  let order = shuffled(words.length), idx = 0, phase = "intro", rows = [], marks = [], current = "", outcome = "", results = words.map(() => 0), freshMiss = false;
  let destroyed = false;
  const canTalk = !!(window.speechSynthesis && typeof SpeechSynthesisUtterance !== "undefined");
  const target = () => words[order[idx]].toLowerCase();
  const root = h("div.sp-wrap");
  const confetti = h("div.sp-confetti");
  area.replaceChildren(h("div.sp-layout", root), confetti);

  const hear = () => speak(words[order[idx]]);
  function startWord() { phase = "spell"; rows = []; marks = []; current = ""; outcome = ""; hear(); paint(); }
  function type(ch) { if (phase === "spell" && current.length < target().length) { current += ch.toLowerCase(); paint(); } }
  function back() { if (phase === "spell" && current.length) { current = current.slice(0, -1); paint(); } }
  function enter() {
    if (phase !== "spell") return;
    if (current.length !== target().length) { const cur = root.querySelector(".sp-row.cur"); if (cur) { cur.classList.remove("nope"); void cur.offsetWidth; cur.classList.add("nope"); } return; }
    const right = current === target();
    rows.push(current); marks.push(mark(target(), current)); current = ""; freshMiss = !right;
    if (right || rows.length >= MAX_TRIES) { phase = "result"; outcome = right ? "correct" : "missed"; results[order[idx]] = right ? 1 : 2; if (right) burst(); }
    paint();
  }
  function next() {
    if (phase !== "result") return;
    idx++;
    if (idx >= words.length) { phase = "done"; if (results.every(r => r === 1)) burst(); paint(); } else startWord();
  }
  function again() { order = shuffled(words.length); idx = 0; results = words.map(() => 0); phase = "intro"; paint(); }

  function rowEl(text, kind, n, m, extra) {
    const cells = [];
    for (let i = 0; i < n; i++) { const ch = text ? text[i] : ""; cells.push(h("span.sp-box" + (ch ? ".has" : "") + (m ? ".m" + m[i] : ""), ch ? ch.toUpperCase() : "")); }
    return h("div.sp-row." + kind + (extra ? "." + extra : ""), { style: { gridTemplateColumns: `repeat(${n}, minmax(0, 1fr))`, maxWidth: (n * 60 + (n - 1) * 5) + "px", "--n": String(n) } }, cells);
  }
  function grid() {
    const n = target().length, out = [];
    rows.forEach((t, i) => out.push(rowEl(t, "done", n, marks[i], freshMiss && i === rows.length - 1 && outcome !== "correct" ? "fresh" : "")));
    if (phase === "spell") out.push(rowEl(current, "cur", n));
    while (out.length < MAX_TRIES) out.push(rowEl("", "empty", n));
    return h("div.sp-grid", out);
  }
  function keyboard() {
    const best = {};
    rows.forEach((t, i) => [...t].forEach((c, k) => { const m = Number(marks[i][k]); if (!(c in best) || m > best[c]) best[c] = m; }));
    const key = (label, fn, cls) => h("button.sp-key" + (cls ? "." + cls : ""), { type: "button", onclick: fn, "aria-label": cls === "back" ? "Backspace" : label }, label);
    const letter = (c) => { const el = key(c, () => type(c)); const m = best[c.toLowerCase()]; if (m !== undefined) el.classList.add("m" + m); return el; };
    return h("div.sp-kb",
      h("div.sp-kbrow", [...KEY_ROWS[0]].map(letter)),
      h("div.sp-kbrow", h("span.sp-half"), [...KEY_ROWS[1]].map(letter), apos ? letter("'") : h("span.sp-half")),
      h("div.sp-kbrow", key("ENTER", enter, "wide"), [...KEY_ROWS[2]].map(letter), key("⌫", back, "wide.back")));
  }
  function burst() {
    const colors = ["#FF5CA8", "#7B3FC4", "#FFD9EA", "#15101C", "#FFFFFF"];
    confetti.replaceChildren(...Array.from({ length: 36 }, (_, i) => h("span", { style: { left: Math.round(Math.random() * 100) + "%", background: colors[i % colors.length], animationDelay: (Math.random() * 0.4).toFixed(2) + "s", "--dx": Math.round(Math.random() * 120 - 60) + "px" } })));
    setTimeout(() => { if (!destroyed) confetti.replaceChildren(); }, 2600);
  }

  function paint() {
    const head = h("div.sp-head", h("span.sp-help.ghost"), h("div.sp-title", title),
      h("div.sp-count", phase === "done" ? "Done" : phase === "intro" ? "" : `Word ${idx + 1}/${words.length}`));
    const kids = [head];
    if (phase !== "done") {
      kids.push(h("label.sp-vol", "🔈 Volume ",
        h("input", { type: "range", min: "0", max: "1", step: "0.05", value: String(getVolume()),
          oninput: (e) => setVolume(parseFloat(e.target.value)),
          onchange: () => speak(words[order[idx]] || "test") })));
    }
    if (phase === "intro") {
      kids.push(h("div.sp-stage",
        h("div.sp-card", h("div.sp-pill", apos ? "CONTRACTIONS" : "LISTEN"), h("div.sp-def", apos ? "You will hear a word. Type it with its apostrophe ( ' )." : "You will hear a word. Type it to spell it."),
          canTalk ? h("button.sp-btn", { type: "button", onclick: startWord }, "🔊 Start") : h("div.sp-watch", "This browser can't read words out loud. Try Chrome, Safari or Edge."))));
    } else if (phase === "done") {
      const right = results.filter(r => r === 1).length;
      kids.push(h("div.sp-card.done", h("div.sp-yay", "All done!"), h("div.sp-sub", `${right} of ${words.length} spelled right`),
        h("div.sp-list", order.map(o => h("div.sp-item" + (results[o] === 1 ? ".ok" : ".no"), h("span.sp-mark", results[o] === 1 ? "✓" : "✗"), words[o]))),
        h("button.sp-btn", { type: "button", onclick: again }, "Play again")));
    } else {
      kids.push(h("div.sp-try", phase === "spell" ? `Try ${Math.min(rows.length + 1, MAX_TRIES)} of ${MAX_TRIES}` : ""));
      kids.push(h("button.sp-hint", { type: "button", onclick: hear }, "🔊 Hear the word again"));
      kids.push(grid());
      if (phase === "result") {
        const last = idx + 1 >= words.length, btn = h("button.sp-btn", { type: "button", onclick: next }, last ? "See my score" : "Next word");
        kids.push(outcome === "correct"
          ? h("div.sp-result.ok", btn)
          : h("div.sp-result.missed", h("div.sp-sub", "Not this time. The word is"), h("div.sp-word", target()), btn));
      } else kids.push(keyboard());
    }
    root.replaceChildren(...kids);
    freshMiss = false;
  }

  const typing = () => { const el = document.activeElement; return el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA"); };
  const onKey = (e) => {
    if (destroyed || typing() || e.ctrlKey || e.metaKey || e.altKey) return;
    if (phase === "spell") {
      if (apos ? /^[a-zA-Z\u0027]$/.test(e.key) : /^[a-zA-Z]$/.test(e.key)) { type(e.key); e.preventDefault(); }
      else if (e.key === "Backspace") { back(); e.preventDefault(); }
      else if (e.key === "Enter") { enter(); e.preventDefault(); }
    } else if (e.key === "Enter" || e.key === " ") {
      if (phase === "intro" && canTalk) startWord(); else if (phase === "result") next(); else if (phase === "done") again();
      e.preventDefault();
    }
  };
  window.addEventListener("keydown", onKey);
  paint();
  return { destroy() { destroyed = true; window.removeEventListener("keydown", onKey); try { window.speechSynthesis && window.speechSynthesis.cancel(); } catch (e) { /* ignore */ } } };
}
